SMARTTRACK WI-FI DESKTOP 3.1.1
Extract the full ZIP and run SmartTrack.exe. Java is included.
Start the existing project's START_SMARTTRACK.cmd for its backend/MySQL.
Connect phone and ESP32 to the laptop's JAY hotspot (2.4 GHz).
Server for both apps: http://192.168.137.1:8080 (check SHOW_LOGIN.cmd).
Sign into both apps with the same username/password from SHOW_LOGIN.cmd.
Desktop readings and Devices status refresh automatically, normally every second.
The footer shows the automatic interval and last update; Refresh now is optional.
No pairing, serial data port or separate phone database is required.
This ZIP supplies the desktop client/Java; the local server runs separately.
Java licenses are in runtime/legal; dependency metadata is in its JARs.
